export default function Home() {
  return (
    <main style={{background:'#000',color:'#0f0',height:'100vh',display:'flex',justifyContent:'center',alignItems:'center',flexDirection:'column'}}>
      <h1 style={{fontSize:'60px'}}>BONYA BET</h1>
      <p>Siaka Siaka Demo Platform</p>
    </main>
  )
}
