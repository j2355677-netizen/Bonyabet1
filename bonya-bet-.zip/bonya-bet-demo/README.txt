BONYA BET DEMO PROJECT

Folders:
- frontend = Next.js frontend
- backend = Express backend

Deploy:
1. Upload frontend to Vercel
2. Upload backend to Railway
